package StepDefinitions;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LogowanieSteps {

    static WebDriver driver;

    @BeforeAll
    public static void setUp(){
        System.setProperty("webdriver.chrome.driver","C://Users//cp//chromedriver_win32//chromedriver.exe");
        driver = new ChromeDriver(); //startuje przeglądarka chrome
        driver.navigate().forward();
        driver.navigate().back();

    }


    @Given("Użytkownik jest na stronie logowania")
    public void użytkownik_jest_na_stronie_logowania() {
        driver.navigate().to("https://the-internet.herokuapp.com/login");
    }

    @When("Użytkownik wprowadza w pole login poprawną wartość")
    public void użytkownik_wprowadza_w_pole_login_poprawną_wartość() {
        driver.findElement(By.id("username")).sendKeys("tomsmith");
    }

    @And("Użytkownik wprowadza w pole password poprawną wartość")
    public void użytkownik_wprowadza_w_pole_password_poprawną_wartość() {
       driver.findElement(By.name("password")).sendKeys("SuperSecretPassword!");
    }

    @And("Użytkownik klika w przycisk Login")
    public void użytkownik_klika_w_przycisk_login() {
        driver.findElement(By.xpath("//*[@id=\"login\"]/button")).click();
    }

    @Then("Użytkownik został poprawnie zalogowany do aplikacji")
    public void użytkownik_został_poprawnie_zalogowany_do_aplikacji() {
        Assert.assertEquals("https://the-internet.herokuapp.com/secure", driver.getCurrentUrl());
        //driver.quit();
        //driver.close();
    }

    @When("Użytkownik wprowadza w pole login niepoprawną wartość")
    public void użytkownik_wprowadza_w_pole_login_niepoprawną_wartość() {
        driver.findElement(By.id("username")).sendKeys("Pszczółka_Maja");
    }

    @Then("Użytkownik nie został poprawnie zalogowany do aplikacji")
    public void użytkownik_nie_został_poprawnie_zalogowany_do_aplikacji() {
        Assert.assertEquals("https://the-internet.herokuapp.com/login", driver.getCurrentUrl());

    }

    @And("Pojawił się komunikat o niepoprawnym zalogowaniu")
    public void pojawił_się_komunikat_o_niepoprawnym_zalogowaniu() {
        Assert.assertEquals("Your username is invalid!\n" + "×", driver.findElement(By.id("flash")).getText());
        //driver.quit();
    }

    @And("Użytkownik wprowadza w pole password niepoprawną wartość")
    public void użytkownik_wprowadza_w_pole_password_niepoprawną_wartość() {
        driver.findElement(By.name("password")).sendKeys("Gucio");
    }

    //Given Użytkownik jest na stronie "https://the-internet.herokuapp.com/login"
    @Given("Użytkownik jest na stronie {string}")
    public void użytkownik_jest_na_stronie(String url) {
        driver.navigate().to(url);
    }

    //When Użytkownik wprowadza w pole login "tomsmith"
    @When("Użytkownik wprowadza w pole login {string}")
    public void użytkownik_wprowadza_w_pole_login(String nazwaUżytkownika) {
        driver.findElement(By.id("username")).sendKeys(nazwaUżytkownika);
    }

    //Then Użytkownik wprowadza w pole password "SuperSecretPassword!"
    @Then("Użytkownik wprowadza w pole password {string}")
    public void użytkownik_wprowadza_w_pole_password(String hasełko) {
        driver.findElement(By.id("password")).sendKeys(hasełko);
    }

    @When("^Użytkownik wprowadza w pole login wartość (.+)$")
    public void uytkownik_wprowadza_w_pole_login(String loginek) {
        driver.findElement(By.id("username")).sendKeys(loginek);
    }

    @Then("^Użytkownik wprowadza w pole password wartość (.+)$")
    public void uytkownik_wprowadza_w_pole_password2(String hasełko) {
        driver.findElement(By.id("password")).sendKeys(hasełko);
    }

    @AfterAll
    public static void tearDown() {
        driver.close();
    }

}

